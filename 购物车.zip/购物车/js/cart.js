// =============== 工具函数 ===============
function formatPrice(price) {
    return '¥' + price.toFixed(2);
}

// =============== 渲染购物车 ===============
function renderCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');
    const checkoutBtn = document.getElementById('checkout-btn');
    const selectAllCheckbox = document.getElementById('select-all');

    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // 如果购物车为空
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart">您的购物车是空的。</p>';
        totalPriceElement.textContent = '¥0.00';
        checkoutBtn.disabled = true;
        if (selectAllCheckbox) selectAllCheckbox.checked = false;
        return;
    }

    // 启用结算按钮
    checkoutBtn.disabled = false;

    // 渲染商品列表
    let html = '';
    cart.forEach(item => {
        html += `
            <div class="cart-item" data-id="${item.id}">
                <input type="checkbox" class="item-checkbox" data-id="${item.id}" ${item.selected ? 'checked' : ''}>
                <img src="${item.image || 'images/default-product.png'}" alt="${item.name}" class="cart-item__image">
                <div class="cart-item__info">
                    <h3 class="cart-item__title">${item.name}</h3>
                    <div class="cart-item__price">单价: ${formatPrice(item.price)}</div>
                    <div class="cart-item__quantity">
                        <label>数量:</label>
                        <div class="quantity-input-group">
                            <button class="qty-btn minus" data-id="${item.id}">-</button>
                            <input type="number" min="1" value="${item.quantity}" data-id="${item.id}" class="quantity-input">
                            <button class="qty-btn plus" data-id="${item.id}">+</button>
                        </div>
                    </div>
                </div>
                <button class="cart-item__remove" data-id="${item.id}">删除</button>
            </div>
        `;
    });
    cartItemsContainer.innerHTML = html;

    // 更新全选状态
    const allSelected = cart.length > 0 && cart.every(item => item.selected);
    if (selectAllCheckbox) {
        selectAllCheckbox.checked = allSelected;
    }

    // 计算总价（所有商品，无论是否选中）
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    totalPriceElement.textContent = formatPrice(total);
}

// =============== 事件监听 ===============
document.addEventListener('DOMContentLoaded', () => {
    // 初始渲染
    renderCart();

    const cartItemsContainer = document.getElementById('cart-items');
    const selectAllCheckbox = document.getElementById('select-all');
    const deleteSelectedBtn = document.getElementById('delete-selected');
    const checkoutBtn = document.getElementById('checkout-btn');

    // ===== 单个商品数量增减 =====
    cartItemsContainer.addEventListener('click', (e) => {
        const id = e.target.dataset.id;
        if (!id) return;

        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const index = cart.findIndex(item => item.id === id);

        if (index === -1) return;

        if (e.target.classList.contains('minus')) {
            if (cart[index].quantity > 1) {
                cart[index].quantity -= 1;
                localStorage.setItem('cart', JSON.stringify(cart));
                renderCart();
            }
        } else if (e.target.classList.contains('plus')) {
            cart[index].quantity += 1;
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        } else if (e.target.classList.contains('cart-item__remove')) {
            // 删除单个商品
            cart.splice(index, 1);
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        }
    });

    // ===== 数量输入框变更 =====
    cartItemsContainer.addEventListener('change', (e) => {
        if (e.target.classList.contains('quantity-input')) {
            const id = e.target.dataset.id;
            let value = parseInt(e.target.value, 10);
            if (isNaN(value) || value < 1) value = 1;

            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const index = cart.findIndex(item => item.id === id);
            if (index !== -1) {
                cart[index].quantity = value;
                localStorage.setItem('cart', JSON.stringify(cart));
                renderCart();
            }
        }
    });

    // ===== 复选框：单个商品选中状态变化 =====
    cartItemsContainer.addEventListener('change', (e) => {
        if (e.target.classList.contains('item-checkbox')) {
            const id = e.target.dataset.id;
            const checked = e.target.checked;

            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const index = cart.findIndex(item => item.id === id);
            if (index !== -1) {
                cart[index].selected = checked;
                localStorage.setItem('cart', JSON.stringify(cart));

                // 更新全选状态
                const allSelected = cart.every(item => item.selected);
                if (selectAllCheckbox) {
                    selectAllCheckbox.checked = allSelected;
                }
            }
        }
    });

    // ===== 全选/取消全选 =====
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', () => {
            const isChecked = selectAllCheckbox.checked;
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart = cart.map(item => ({ ...item, selected: isChecked }));
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        });
    }

    // ===== 删除选中项 =====
    if (deleteSelectedBtn) {
        deleteSelectedBtn.addEventListener('click', () => {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const newCart = cart.filter(item => !item.selected);
            if (newCart.length !== cart.length) {
                localStorage.setItem('cart', JSON.stringify(newCart));
                renderCart();
            }
        });
    }

    // ===== 去结算 =====
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            // 检查登录状态（假设通过 localStorage 判断）
            const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
            if (!isLoggedIn) {
                alert('请先登录后再结算！');
                window.location.href = 'login.html';
                return;
            }

            // 可跳转到订单确认页
            if (JSON.parse(localStorage.getItem('cart') || '[]').length === 0) {
                alert('购物车为空，无法结算！');
                return;
            }
            checkoutBtn.addEventListener('click', () => {
            alert('结算功能暂未实现');
            });
            //window.location.href = 'checkout.html';
        });
    }

    // ===== 滚动按钮：回到顶部 / 底部 =====
    const goToTopBtn = document.getElementById('go-to-top');
    const goToBottomBtn = document.getElementById('go-to-bottom');

    if (goToTopBtn) {
        goToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (goToBottomBtn) {
        goToBottomBtn.addEventListener('click', () => {
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        });
    }
});