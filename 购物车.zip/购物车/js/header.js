// 页眉功能
document.addEventListener('DOMContentLoaded', () => {
  // 检查登录状态
  const checkLoginStatus = () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userStatus = document.getElementById('user-status');
    const loginBtn = document.getElementById('login-btn');
    
    if (isLoggedIn) {
      const username = localStorage.getItem('username');
      userStatus.textContent = `欢迎, ${username}`;
      if (loginBtn) {
        loginBtn.style.display = 'none';
      }
    } else {
      userStatus.textContent = '未登录';
      if (loginBtn) {
        loginBtn.style.display = 'block';
        loginBtn.addEventListener('click', () => {
          window.location.href = 'login.html';
        });
      }
    }
  };

  // 初始化
  checkLoginStatus();
});